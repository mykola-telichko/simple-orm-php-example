<?php

class SmplOrm
{
    private static $db;


    #  Check object
    public static function Setup($db_inst, $encod = "utf8")
    {
        if ( is_object($db_inst) ) {

            self::$db = $db_inst;

        } else {

            throw new Exception("Parameters $db_inst is not object", 1);
            return false;
        }
    }


    # set encoding
    public static function setEncoding($encod)
    {
        return self::$db->query("SET NAMES '$encod'; ");
    }


    # Show error
    public function getError()
    {
        return self::$db->error . "[" . self::$db->errno . "]";
    }


    # return query
    public function getQueryTo($query)
    {
        return self::$db->query($query);
    }


    # search on id //is_int better is_numeric
    public static function getID($id)
    {
        if ( is_int($id) ) {

            $query = "SELECT * FROM `"
            . get_called_class() . "`
            WHERE `" . key(get_class_vars(get_called_class())) . "`
            = $id LIMIT 1";

            //echo $query; - check query

        $result = self::$db->query($query);

        if ( $result->num_rows == 1 ) {

            $row = $result->fetch_object();
            $className = get_called_class();
            $InstanceClass = new $className();

            foreach ($row as $k => $v) {

                $InstanceClass->$k = $v;

            }

            return $InstanceClass;

            } else return false;

        } else {

        throw new Exception("Parameter $id no a number", 1);
        return false;

        }
    }


    # Delete
    public static function Remove($removeClass)
    {
        if ( !is_object($removeClass) ) return false;

        $id = key(get_class_vars(get_called_class()));

        if ( !empty($removeClass->$id) ) {

            $query = "DELETE FROM `" . get_called_class() ."`
            WHERE `$id` = " . $removeClass->$id . "LIMIT 1";

            return self::$db->query($query);

        } else return false;
    }


    # clear contain table
    public static function TruncateTable()
    {
        $query = "TRUNCATE TABLE" . get_called_class();
        return self::$db->query($query);
    }



}
