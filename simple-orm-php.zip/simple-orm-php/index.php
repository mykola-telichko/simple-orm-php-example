<?php

include "orm.php";


class film extends SmplOrm
{
    public $film_id;
    public $film_name;
    public $film_count;
}


class produce extends SmplOrm
{
    public $film_id;
    public $produce_id;
    public $produce_name;
    public $description;
}


try {

    # run orm, pass param in setup

    SmplORM::Setup(new mysqli("localhost",
    "root", "", "orm_film"))/*or die(SmplOrm::getError())*/;


    # check film id
    $film = film::getID(2);

    # show contain obj
    echo "<pre>";
    print_r($film);
    echo "</pre>";


    # check produce
    $produce = produce::getID(1);

    # show contain obj
    echo "<pre>";
    print_r($produce);
    echo "</pre>";

    //echo film::Remove($film) ? "Film has delete" : "Not delete";
    //or film::Remove(film::getID(1));

    //echo film::TruncateTable() ? "Now table is clear" : "Error table is not clear";

} catch (Exception $ex) {

    echo "Sorry this exception";

}
